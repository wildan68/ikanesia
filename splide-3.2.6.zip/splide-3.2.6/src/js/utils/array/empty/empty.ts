/**
 * Empties the array.
 *
 * @param array - A array to empty.
 */
export function empty( array: any[] ): void {
  array.length = 0;
}
